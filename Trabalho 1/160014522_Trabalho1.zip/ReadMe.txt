Aluna    : Mariana Alencar do Vale
matricula: 160014522

--Trabalho 1--
como rodar: 
	1) Compile com o comando make
	2) digite ./montador nome_do_arquivo.asm
	3) digite ./compilador nome_do_arquivo.obj